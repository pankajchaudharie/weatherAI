"""
app.py
Diabetes Mellitus Diagnosis & Treatment System
Flask application leveraging Data Science & ML for healthcare in developing nations.
"""

from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import os
import json
from model import DiabetesModel

app = Flask(__name__)

# Initialize ML model
diabetes_model = DiabetesModel()


@app.route("/")
def index():
    """Home page with system overview."""
    return render_template("index.html")


@app.route("/diagnose")
def diagnose():
    """Patient diagnosis form page."""
    regions = diabetes_model.get_supported_regions()
    return render_template("diagnose.html", regions=regions)


@app.route("/predict", methods=["POST"])
def predict():
    """Handle diagnosis prediction request."""
    try:
        # Collect form data
        patient_data = {
            "age": int(request.form.get("age", 35)),
            "gender": int(request.form.get("gender", 0)),
            "pregnancies": int(request.form.get("pregnancies", 0)),
            "glucose": int(request.form.get("glucose", 100)),
            "blood_pressure": int(request.form.get("blood_pressure", 70)),
            "skin_thickness": int(request.form.get("skin_thickness", 25)),
            "insulin": int(request.form.get("insulin", 100)),
            "bmi": float(request.form.get("bmi", 25.0)),
            "hba1c": float(request.form.get("hba1c", 5.5)),
            "diabetes_pedigree_function": float(request.form.get("dpf", 0.3)),
            "physical_activity_hrs": float(request.form.get("physical_activity", 3.0)),
            "smoking": int(request.form.get("smoking", 0)),
            "family_history": int(request.form.get("family_history", 0)),
            "region": request.form.get("region", "South Asia"),
            "healthcare_access": int(request.form.get("healthcare_access", 3)),
        }

        # Get prediction
        result = diabetes_model.predict(patient_data)

        return render_template(
            "result.html",
            patient=patient_data,
            result=result,
            metrics=diabetes_model.metrics,
        )
    except Exception as e:
        return render_template("error.html", message=f"Prediction error: {str(e)}")


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """REST API endpoint for predictions (JSON)."""
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing patient data"}), 400

    required = ["age", "glucose", "bmi", "hba1c"]
    for field in required:
        if field not in data:
            return jsonify({"error": f"Missing required field: {field}"}), 400

    # Set defaults for missing optional fields
    defaults = {
        "gender": 0, "pregnancies": 0, "blood_pressure": 72,
        "skin_thickness": 25, "insulin": 100,
        "diabetes_pedigree_function": 0.3, "physical_activity_hrs": 3.0,
        "smoking": 0, "family_history": 0, "region": "South Asia",
        "healthcare_access": 3
    }
    for key, val in defaults.items():
        data.setdefault(key, val)

    result = diabetes_model.predict(data)
    return jsonify({"patient_data": data, "prediction": result})


@app.route("/analytics")
def analytics():
    """Model performance analytics and data insights."""
    metrics = diabetes_model.metrics if diabetes_model.is_trained else {}
    feature_importance = diabetes_model.feature_importance if diabetes_model.is_trained else {}

    # Load dataset statistics for charts
    chart_data = {}
    try:
        df = pd.read_csv("data/diabetes_data.csv")

        # Age distribution
        age_bins = pd.cut(df["age"], bins=[20, 30, 40, 50, 60, 70, 80])
        age_dist = age_bins.value_counts().sort_index()
        chart_data["age_distribution"] = {
            "labels": [str(x) for x in age_dist.index],
            "diabetic": [],
            "non_diabetic": []
        }
        for bin_range in age_dist.index:
            mask = pd.cut(df["age"], bins=[20, 30, 40, 50, 60, 70, 80]) == bin_range
            chart_data["age_distribution"]["diabetic"].append(int(df[mask & (df["outcome"] == 1)].shape[0]))
            chart_data["age_distribution"]["non_diabetic"].append(int(df[mask & (df["outcome"] == 0)].shape[0]))

        # Region-wise diabetes prevalence
        region_stats = df.groupby("region")["outcome"].agg(["sum", "count"]).reset_index()
        region_stats["prevalence"] = (region_stats["sum"] / region_stats["count"] * 100).round(1)
        chart_data["region_prevalence"] = {
            "labels": region_stats["region"].tolist(),
            "values": region_stats["prevalence"].tolist(),
            "counts": region_stats["sum"].tolist(),
        }

        # BMI vs Glucose scatter (sample)
        sample = df.sample(min(300, len(df)), random_state=42)
        chart_data["bmi_glucose"] = {
            "diabetic": {"bmi": sample[sample["outcome"] == 1]["bmi"].tolist(),
                         "glucose": sample[sample["outcome"] == 1]["glucose"].tolist()},
            "non_diabetic": {"bmi": sample[sample["outcome"] == 0]["bmi"].tolist(),
                             "glucose": sample[sample["outcome"] == 0]["glucose"].tolist()},
        }

        # Healthcare access impact
        access_stats = df.groupby("healthcare_access")["outcome"].mean().round(3) * 100
        chart_data["healthcare_impact"] = {
            "labels": [f"Level {x}" for x in access_stats.index],
            "values": access_stats.tolist(),
        }

        # Key statistics
        chart_data["stats"] = {
            "total_patients": len(df),
            "diabetic_count": int(df["outcome"].sum()),
            "avg_age": round(df["age"].mean(), 1),
            "avg_glucose": round(df["glucose"].mean(), 1),
            "avg_bmi": round(df["bmi"].mean(), 1),
            "avg_hba1c": round(df["hba1c"].mean(), 1),
        }

    except FileNotFoundError:
        pass

    return render_template(
        "analytics.html",
        metrics=metrics,
        feature_importance=feature_importance,
        chart_data=json.dumps(chart_data),
    )


@app.route("/about")
def about():
    """About page with research context."""
    return render_template("about.html")


def initialize():
    """Initialize the application - load or train model."""
    if not diabetes_model.load_model():
        print("\n*** No pre-trained model found. Training new model... ***\n")
        if not os.path.exists("data/diabetes_data.csv"):
            print("Generating synthetic diabetes dataset...")
            from generate_dataset import generate_diabetes_dataset
            generate_diabetes_dataset()
        diabetes_model.train()


if __name__ == "__main__":
    initialize()
    print("\n" + "=" * 60)
    print("  DIABETES DIAGNOSIS & TREATMENT SYSTEM")
    print("  Data Science for Healthcare in Developing Nations")
    print("  Running at: http://127.0.0.1:5001")
    print("=" * 60 + "\n")
    app.run(debug=True, host="127.0.0.1", port=5001)
