"""
model.py
Machine Learning Models for Diabetes Mellitus Diagnosis
Uses multiple algorithms: Random Forest, Gradient Boosting, Logistic Regression, SVM
with ensemble voting for final prediction.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import (
    RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
)
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)
import joblib
import os
import json

MODEL_DIR = "trained_model"


class DiabetesModel:
    """Ensemble ML model for diabetes diagnosis prediction."""

    def __init__(self):
        self.model = None
        self.rf_model = None
        self.gb_model = None
        self.lr_model = None
        self.scaler = StandardScaler()
        self.region_encoder = LabelEncoder()
        self.feature_names = []
        self.metrics = {}
        self.is_trained = False
        self.feature_importance = {}

    def _prepare_features(self, df):
        """Prepare feature matrix from raw patient data."""
        df = df.copy()
        df["region_encoded"] = self.region_encoder.transform(df["region"])

        # Derived features
        df["glucose_bmi_interaction"] = df["glucose"] * df["bmi"] / 100
        df["age_bmi_interaction"] = df["age"] * df["bmi"] / 100
        df["insulin_glucose_ratio"] = df["insulin"] / (df["glucose"] + 1)
        df["risk_factors_count"] = (
            (df["bmi"] > 30).astype(int) +
            (df["glucose"] > 140).astype(int) +
            (df["hba1c"] > 6.5).astype(int) +
            (df["blood_pressure"] > 90).astype(int) +
            df["family_history"] +
            df["smoking"] +
            (df["physical_activity_hrs"] < 2).astype(int)
        )

        self.feature_names = [
            "age", "gender", "pregnancies", "glucose", "blood_pressure",
            "skin_thickness", "insulin", "bmi", "hba1c",
            "diabetes_pedigree_function", "physical_activity_hrs",
            "smoking", "family_history", "healthcare_access", "region_encoded",
            "glucose_bmi_interaction", "age_bmi_interaction",
            "insulin_glucose_ratio", "risk_factors_count"
        ]
        return df[self.feature_names]

    def train(self, data_path="data/diabetes_data.csv"):
        """Train the ensemble diabetes diagnosis model."""
        print("=" * 60)
        print("  DIABETES DIAGNOSIS ML MODEL - TRAINING")
        print("  Data Science for Healthcare in Developing Nations")
        print("=" * 60)

        # Load data
        df = pd.read_csv(data_path)
        print(f"\nDataset: {len(df)} patient records")
        print(f"Positive (Diabetic): {df['outcome'].sum()} ({df['outcome'].mean()*100:.1f}%)")
        print(f"Negative (Non-diabetic): {len(df) - df['outcome'].sum()}")

        # Encode region
        self.region_encoder.fit(df["region"])

        # Prepare features
        X = self._prepare_features(df)
        y = df["outcome"]

        # Scale features
        X_scaled = self.scaler.fit_transform(X)

        # Split data (80/20)
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42, stratify=y
        )

        print(f"\nTraining set: {len(X_train)} | Test set: {len(X_test)}")

        # --- Model 1: Random Forest ---
        print("\n[1/4] Training Random Forest Classifier...")
        self.rf_model = RandomForestClassifier(
            n_estimators=200, max_depth=12, min_samples_split=5,
            min_samples_leaf=2, random_state=42, n_jobs=-1
        )
        self.rf_model.fit(X_train, y_train)
        rf_pred = self.rf_model.predict(X_test)
        rf_acc = accuracy_score(y_test, rf_pred)
        print(f"   Accuracy: {rf_acc:.4f} | F1: {f1_score(y_test, rf_pred):.4f}")

        # --- Model 2: Gradient Boosting ---
        print("\n[2/4] Training Gradient Boosting Classifier...")
        self.gb_model = GradientBoostingClassifier(
            n_estimators=200, max_depth=6, learning_rate=0.1,
            min_samples_split=5, random_state=42
        )
        self.gb_model.fit(X_train, y_train)
        gb_pred = self.gb_model.predict(X_test)
        gb_acc = accuracy_score(y_test, gb_pred)
        print(f"   Accuracy: {gb_acc:.4f} | F1: {f1_score(y_test, gb_pred):.4f}")

        # --- Model 3: Logistic Regression ---
        print("\n[3/4] Training Logistic Regression...")
        self.lr_model = LogisticRegression(
            max_iter=1000, C=1.0, random_state=42
        )
        self.lr_model.fit(X_train, y_train)
        lr_pred = self.lr_model.predict(X_test)
        lr_acc = accuracy_score(y_test, lr_pred)
        print(f"   Accuracy: {lr_acc:.4f} | F1: {f1_score(y_test, lr_pred):.4f}")

        # --- Model 4: Ensemble Voting Classifier ---
        print("\n[4/4] Building Ensemble Voting Classifier...")
        self.model = VotingClassifier(
            estimators=[
                ('rf', self.rf_model),
                ('gb', self.gb_model),
                ('lr', self.lr_model),
            ],
            voting='soft'
        )
        self.model.fit(X_train, y_train)
        ensemble_pred = self.model.predict(X_test)
        ensemble_proba = self.model.predict_proba(X_test)[:, 1]

        # --- Compute Final Metrics ---
        accuracy = accuracy_score(y_test, ensemble_pred)
        precision = precision_score(y_test, ensemble_pred)
        recall = recall_score(y_test, ensemble_pred)
        f1 = f1_score(y_test, ensemble_pred)
        auc_roc = roc_auc_score(y_test, ensemble_proba)
        cm = confusion_matrix(y_test, ensemble_pred)

        # Cross-validation
        cv_scores = cross_val_score(self.model, X_scaled, y, cv=5, scoring='accuracy')

        print(f"\n{'='*60}")
        print(f"  ENSEMBLE MODEL PERFORMANCE (Soft Voting)")
        print(f"{'='*60}")
        print(f"  Accuracy:    {accuracy:.4f} ({accuracy*100:.1f}%)")
        print(f"  Precision:   {precision:.4f}")
        print(f"  Recall:      {recall:.4f}")
        print(f"  F1-Score:    {f1:.4f}")
        print(f"  AUC-ROC:     {auc_roc:.4f}")
        print(f"  Cross-Val:   {cv_scores.mean():.4f} (+/- {cv_scores.std()*2:.4f})")
        print(f"\n  Confusion Matrix:")
        print(f"  TN={cm[0][0]} | FP={cm[0][1]}")
        print(f"  FN={cm[1][0]} | TP={cm[1][1]}")

        # Feature importance from Random Forest
        importance = self.rf_model.feature_importances_
        self.feature_importance = dict(zip(self.feature_names, importance.round(4).tolist()))
        sorted_features = sorted(self.feature_importance.items(), key=lambda x: x[1], reverse=True)

        print(f"\n  Top 10 Feature Importance:")
        for i, (feat, imp) in enumerate(sorted_features[:10], 1):
            print(f"    {i}. {feat}: {imp:.4f}")

        # Store metrics
        self.metrics = {
            "accuracy": round(accuracy, 4),
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1_score": round(f1, 4),
            "auc_roc": round(auc_roc, 4),
            "cross_val_mean": round(cv_scores.mean(), 4),
            "cross_val_std": round(cv_scores.std(), 4),
            "confusion_matrix": {"tn": int(cm[0][0]), "fp": int(cm[0][1]),
                                 "fn": int(cm[1][0]), "tp": int(cm[1][1])},
            "individual_models": {
                "random_forest": round(rf_acc, 4),
                "gradient_boosting": round(gb_acc, 4),
                "logistic_regression": round(lr_acc, 4),
            },
            "feature_importance": dict(sorted_features[:10]),
            "total_records": len(df),
            "training_records": len(X_train),
            "test_records": len(X_test),
            "diabetic_ratio": round(df['outcome'].mean(), 3),
        }

        self.is_trained = True
        self._save_model()

        print(f"\n{'='*60}")
        print(f"  MODEL TRAINING COMPLETE")
        print(f"{'='*60}")
        return self.metrics

    def _save_model(self):
        """Save trained models to disk."""
        os.makedirs(MODEL_DIR, exist_ok=True)
        joblib.dump(self.model, os.path.join(MODEL_DIR, "ensemble_model.pkl"))
        joblib.dump(self.rf_model, os.path.join(MODEL_DIR, "rf_model.pkl"))
        joblib.dump(self.gb_model, os.path.join(MODEL_DIR, "gb_model.pkl"))
        joblib.dump(self.lr_model, os.path.join(MODEL_DIR, "lr_model.pkl"))
        joblib.dump(self.scaler, os.path.join(MODEL_DIR, "scaler.pkl"))
        joblib.dump(self.region_encoder, os.path.join(MODEL_DIR, "region_encoder.pkl"))
        with open(os.path.join(MODEL_DIR, "metrics.json"), "w") as f:
            json.dump(self.metrics, f, indent=2)
        with open(os.path.join(MODEL_DIR, "feature_importance.json"), "w") as f:
            json.dump(self.feature_importance, f, indent=2)
        print("\nModels saved to trained_model/")

    def load_model(self):
        """Load pre-trained models from disk."""
        try:
            self.model = joblib.load(os.path.join(MODEL_DIR, "ensemble_model.pkl"))
            self.rf_model = joblib.load(os.path.join(MODEL_DIR, "rf_model.pkl"))
            self.gb_model = joblib.load(os.path.join(MODEL_DIR, "gb_model.pkl"))
            self.lr_model = joblib.load(os.path.join(MODEL_DIR, "lr_model.pkl"))
            self.scaler = joblib.load(os.path.join(MODEL_DIR, "scaler.pkl"))
            self.region_encoder = joblib.load(os.path.join(MODEL_DIR, "region_encoder.pkl"))
            with open(os.path.join(MODEL_DIR, "metrics.json"), "r") as f:
                self.metrics = json.load(f)
            with open(os.path.join(MODEL_DIR, "feature_importance.json"), "r") as f:
                self.feature_importance = json.load(f)
            self.feature_names = [
                "age", "gender", "pregnancies", "glucose", "blood_pressure",
                "skin_thickness", "insulin", "bmi", "hba1c",
                "diabetes_pedigree_function", "physical_activity_hrs",
                "smoking", "family_history", "healthcare_access", "region_encoded",
                "glucose_bmi_interaction", "age_bmi_interaction",
                "insulin_glucose_ratio", "risk_factors_count"
            ]
            self.is_trained = True
            print("Models loaded successfully!")
            return True
        except FileNotFoundError:
            print("No trained models found. Please train the model first.")
            return False

    def predict(self, patient_data):
        """
        Make diabetes diagnosis prediction for a patient.
        Returns prediction, probability, risk level, and recommendations.
        """
        if not self.is_trained:
            raise ValueError("Model not trained. Call train() or load_model() first.")

        # Build input dataframe
        input_df = pd.DataFrame([patient_data])
        X = self._prepare_features(input_df)
        X_scaled = self.scaler.transform(X)

        # Ensemble prediction
        prediction = self.model.predict(X_scaled)[0]
        probability = self.model.predict_proba(X_scaled)[0]

        # Individual model predictions for comparison
        rf_pred = self.rf_model.predict_proba(X_scaled)[0][1]
        gb_pred = self.gb_model.predict_proba(X_scaled)[0][1]
        lr_pred = self.lr_model.predict_proba(X_scaled)[0][1]

        diabetes_prob = probability[1]
        confidence = max(probability) * 100

        # Risk level determination
        if diabetes_prob < 0.25:
            risk_level = "Low Risk"
            risk_color = "green"
        elif diabetes_prob < 0.50:
            risk_level = "Moderate Risk"
            risk_color = "yellow"
        elif diabetes_prob < 0.75:
            risk_level = "High Risk"
            risk_color = "orange"
        else:
            risk_level = "Very High Risk"
            risk_color = "red"

        # Generate treatment recommendations
        recommendations = self._generate_recommendations(patient_data, diabetes_prob, risk_level)

        # Key risk factors for this patient
        risk_factors = self._identify_risk_factors(patient_data)

        return {
            "prediction": int(prediction),
            "diagnosis": "Diabetic" if prediction == 1 else "Non-Diabetic",
            "diabetes_probability": round(diabetes_prob * 100, 1),
            "confidence": round(confidence, 1),
            "risk_level": risk_level,
            "risk_color": risk_color,
            "individual_models": {
                "Random Forest": round(rf_pred * 100, 1),
                "Gradient Boosting": round(gb_pred * 100, 1),
                "Logistic Regression": round(lr_pred * 100, 1),
            },
            "recommendations": recommendations,
            "risk_factors": risk_factors,
        }

    def _generate_recommendations(self, patient_data, prob, risk_level):
        """Generate personalized treatment recommendations."""
        recs = []

        # Lifestyle recommendations
        if patient_data.get("bmi", 0) > 25:
            recs.append({
                "category": "Weight Management",
                "icon": "fas fa-weight",
                "text": f"BMI is {patient_data['bmi']} (overweight). Target BMI < 25 through balanced diet and exercise.",
                "priority": "high"
            })

        if patient_data.get("physical_activity_hrs", 0) < 3:
            recs.append({
                "category": "Physical Activity",
                "icon": "fas fa-running",
                "text": "Increase physical activity to at least 150 minutes/week of moderate aerobic exercise.",
                "priority": "high"
            })

        if patient_data.get("glucose", 0) > 126:
            recs.append({
                "category": "Blood Sugar Control",
                "icon": "fas fa-tint",
                "text": f"Fasting glucose ({patient_data['glucose']} mg/dL) is elevated. Regular monitoring recommended.",
                "priority": "high"
            })

        if patient_data.get("hba1c", 0) > 6.5:
            recs.append({
                "category": "HbA1c Management",
                "icon": "fas fa-chart-line",
                "text": f"HbA1c ({patient_data['hba1c']}%) indicates poor glycemic control. Target < 6.5%.",
                "priority": "high"
            })

        if patient_data.get("blood_pressure", 0) > 90:
            recs.append({
                "category": "Blood Pressure",
                "icon": "fas fa-heartbeat",
                "text": f"Diastolic BP ({patient_data['blood_pressure']} mmHg) elevated. Monitor and manage hypertension.",
                "priority": "medium"
            })

        if patient_data.get("smoking", 0) == 1:
            recs.append({
                "category": "Smoking Cessation",
                "icon": "fas fa-smoking-ban",
                "text": "Smoking significantly increases diabetic complications. Quit smoking immediately.",
                "priority": "high"
            })

        # General recommendations
        recs.append({
            "category": "Regular Screening",
            "icon": "fas fa-stethoscope",
            "text": "Regular health screenings every 3-6 months for early detection and monitoring.",
            "priority": "medium"
        })

        if patient_data.get("healthcare_access", 3) <= 2:
            recs.append({
                "category": "Healthcare Access",
                "icon": "fas fa-hospital",
                "text": "Limited healthcare access detected. Seek community health programs and mobile clinics.",
                "priority": "high"
            })

        # Dietary recommendations
        recs.append({
            "category": "Dietary Changes",
            "icon": "fas fa-apple-alt",
            "text": "Follow a low-glycemic diet rich in fiber, vegetables, and whole grains. Limit refined sugars.",
            "priority": "medium"
        })

        if prob > 0.5:
            recs.append({
                "category": "Medical Consultation",
                "icon": "fas fa-user-md",
                "text": "Consult an endocrinologist for further evaluation and possible medication (Metformin).",
                "priority": "high"
            })

        return recs

    def _identify_risk_factors(self, patient_data):
        """Identify key risk factors for the patient."""
        factors = []
        if patient_data.get("glucose", 0) > 126:
            factors.append("High Fasting Glucose")
        if patient_data.get("bmi", 0) > 30:
            factors.append("Obesity (BMI > 30)")
        elif patient_data.get("bmi", 0) > 25:
            factors.append("Overweight (BMI > 25)")
        if patient_data.get("hba1c", 0) > 6.5:
            factors.append("Elevated HbA1c")
        if patient_data.get("age", 0) > 45:
            factors.append("Age > 45")
        if patient_data.get("family_history", 0) == 1:
            factors.append("Family History of Diabetes")
        if patient_data.get("blood_pressure", 0) > 90:
            factors.append("High Blood Pressure")
        if patient_data.get("physical_activity_hrs", 10) < 2:
            factors.append("Sedentary Lifestyle")
        if patient_data.get("smoking", 0) == 1:
            factors.append("Smoking")
        if patient_data.get("healthcare_access", 5) <= 2:
            factors.append("Limited Healthcare Access")
        return factors

    def get_supported_regions(self):
        """Return list of regions the model was trained on."""
        if self.is_trained:
            return list(self.region_encoder.classes_)
        return ["South Asia", "Sub-Saharan Africa", "Southeast Asia", "Latin America", "Middle East"]


if __name__ == "__main__":
    model = DiabetesModel()
    model.train()
    print("\n--- Test Prediction ---")
    test_patient = {
        "age": 52,
        "gender": 0,
        "pregnancies": 4,
        "glucose": 148,
        "blood_pressure": 88,
        "skin_thickness": 35,
        "insulin": 180,
        "bmi": 33.6,
        "hba1c": 7.2,
        "diabetes_pedigree_function": 0.627,
        "physical_activity_hrs": 1.5,
        "smoking": 0,
        "family_history": 1,
        "region": "South Asia",
        "healthcare_access": 2,
    }
    result = model.predict(test_patient)
    print(f"\nDiagnosis: {result['diagnosis']}")
    print(f"Diabetes Probability: {result['diabetes_probability']}%")
    print(f"Risk Level: {result['risk_level']}")
    print(f"Confidence: {result['confidence']}%")
    print(f"\nRisk Factors: {', '.join(result['risk_factors'])}")
