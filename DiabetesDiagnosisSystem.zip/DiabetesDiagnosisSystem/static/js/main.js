// main.js - Diabetes Diagnosis System

document.addEventListener('DOMContentLoaded', function() {
    // Form submission loading state
    const form = document.getElementById('diagnosisForm');
    if (form) {
        form.addEventListener('submit', function() {
            const btn = document.getElementById('submitBtn');
            if (btn) {
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Running AI Diagnosis...';
                btn.disabled = true;
                btn.style.opacity = '0.7';
            }
        });
    }

    // Animate elements on scroll
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.feature-card, .impact-card, .rec-card, .model-pred-card, .metric-summary-card').forEach(function(el) {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(el);
    });

    // BMI Calculator helper
    const bmiInput = document.getElementById('bmi');
    if (bmiInput) {
        bmiInput.addEventListener('change', function() {
            const val = parseFloat(this.value);
            let status = '';
            if (val < 18.5) status = 'Underweight';
            else if (val < 25) status = 'Normal';
            else if (val < 30) status = 'Overweight';
            else status = 'Obese';

            const small = this.parentElement.querySelector('small');
            if (small) {
                small.textContent = `BMI ${val}: ${status} | Normal: 18.5-24.9`;
            }
        });
    }

    // Dynamic glucose indicator
    const glucoseInput = document.getElementById('glucose');
    if (glucoseInput) {
        glucoseInput.addEventListener('change', function() {
            const val = parseInt(this.value);
            let status = '';
            if (val < 100) status = 'Normal';
            else if (val < 126) status = 'Pre-diabetic range';
            else status = 'Diabetic range (High!)';

            const small = this.parentElement.querySelector('small');
            if (small) {
                small.textContent = `Glucose ${val}: ${status}`;
                small.style.color = val >= 126 ? '#e53e3e' : val >= 100 ? '#ed8936' : '#38a169';
            }
        });
    }

    // HbA1c indicator
    const hba1cInput = document.getElementById('hba1c');
    if (hba1cInput) {
        hba1cInput.addEventListener('change', function() {
            const val = parseFloat(this.value);
            let status = '';
            if (val < 5.7) status = 'Normal';
            else if (val < 6.5) status = 'Pre-diabetic range';
            else status = 'Diabetic range (High!)';

            const small = this.parentElement.querySelector('small');
            if (small) {
                small.textContent = `HbA1c ${val}%: ${status}`;
                small.style.color = val >= 6.5 ? '#e53e3e' : val >= 5.7 ? '#ed8936' : '#38a169';
            }
        });
    }

    // Toggle pregnancies based on gender
    const genderSelect = document.getElementById('gender');
    const pregInput = document.getElementById('pregnancies');
    if (genderSelect && pregInput) {
        genderSelect.addEventListener('change', function() {
            if (this.value === '1') { // Male
                pregInput.value = 0;
                pregInput.disabled = true;
            } else {
                pregInput.disabled = false;
            }
        });
    }
});
