"""
generate_dataset.py
Generates a realistic synthetic diabetes dataset modeled on the Pima Indians Diabetes Database
and extended with developing nations healthcare context (India, Bangladesh, Nigeria, Kenya, etc.)
"""

import pandas as pd
import numpy as np

np.random.seed(42)

def generate_diabetes_dataset(n_samples=2000):
    """
    Generate a synthetic diabetes dataset with clinical parameters.
    Features based on standard diabetes diagnostic criteria used in developing nations.
    """
    print("Generating Diabetes Mellitus Diagnostic Dataset...")
    print("=" * 60)

    # --- Generate features ---
    # Age distribution (20-80, skewed towards 30-55 for developing nations)
    age = np.random.normal(45, 12, n_samples).clip(20, 80).astype(int)

    # Gender (0=Female, 1=Male)
    gender = np.random.binomial(1, 0.48, n_samples)

    # BMI - Body Mass Index (kg/m²) - higher in diabetic populations
    bmi = np.random.normal(27.5, 6.5, n_samples).clip(15, 55).round(1)

    # Number of Pregnancies (for females, 0 for males)
    pregnancies = np.where(gender == 0,
                           np.random.poisson(3, n_samples).clip(0, 15), 0)

    # Glucose Level (mg/dL) - fasting plasma glucose
    glucose = np.random.normal(120, 35, n_samples).clip(50, 250).round(0).astype(int)

    # Blood Pressure - Diastolic (mm Hg)
    blood_pressure = np.random.normal(75, 12, n_samples).clip(40, 130).round(0).astype(int)

    # Skin Thickness (mm) - triceps skin fold thickness
    skin_thickness = np.random.normal(28, 10, n_samples).clip(7, 60).round(0).astype(int)

    # Insulin Level (mu U/ml) - 2-Hour serum insulin
    insulin = np.random.lognormal(4.5, 0.7, n_samples).clip(15, 850).round(0).astype(int)

    # HbA1c (%) - Glycated Hemoglobin - KEY diabetes marker
    hba1c = np.random.normal(6.2, 1.5, n_samples).clip(3.5, 14.0).round(1)

    # Diabetes Pedigree Function (genetic factor)
    dpf = np.random.exponential(0.4, n_samples).clip(0.05, 2.5).round(3)

    # Physical Activity Level (hours/week)
    physical_activity = np.random.exponential(3, n_samples).clip(0, 20).round(1)

    # Smoking Status (0=No, 1=Yes)
    smoking = np.random.binomial(1, 0.25, n_samples)

    # Family History of Diabetes (0=No, 1=Yes)
    family_history = np.random.binomial(1, 0.35, n_samples)

    # Region (developing nations)
    regions = ["South Asia", "Sub-Saharan Africa", "Southeast Asia", "Latin America", "Middle East"]
    region_probs = [0.35, 0.20, 0.20, 0.15, 0.10]
    region = np.random.choice(regions, n_samples, p=region_probs)

    # Healthcare Access Level (1-5, 1=very poor, 5=good)
    healthcare_access = np.random.choice([1, 2, 3, 4, 5], n_samples, p=[0.15, 0.25, 0.30, 0.20, 0.10])

    # --- Generate Target (Diabetes Outcome) ---
    # Based on clinical risk factors
    risk_score = (
        0.25 * ((glucose - 100) / 50) +
        0.15 * ((bmi - 25) / 10) +
        0.15 * ((hba1c - 5.7) / 2) +
        0.10 * ((age - 30) / 20) +
        0.08 * family_history +
        0.07 * ((blood_pressure - 70) / 20) +
        0.05 * dpf +
        0.05 * smoking +
        -0.05 * (physical_activity / 10) +
        0.05 * ((insulin - 100) / 200) +
        np.random.normal(0, 0.15, n_samples)
    )

    # Convert to probability using sigmoid
    probability = 1 / (1 + np.exp(-3 * risk_score))
    outcome = (probability > 0.62).astype(int)

    # Diabetes Type (for those diagnosed)
    # Type 2 is dominant in developing nations (90-95%)
    diabetes_type = np.where(outcome == 1,
                             np.where(np.random.random(n_samples) < 0.93, "Type 2", "Type 1"),
                             "None")

    # Risk Level
    risk_level = np.where(probability < 0.3, "Low",
                 np.where(probability < 0.6, "Moderate",
                 np.where(probability < 0.8, "High", "Very High")))

    # Build DataFrame
    df = pd.DataFrame({
        "age": age,
        "gender": gender,
        "pregnancies": pregnancies,
        "glucose": glucose,
        "blood_pressure": blood_pressure,
        "skin_thickness": skin_thickness,
        "insulin": insulin,
        "bmi": bmi,
        "hba1c": hba1c,
        "diabetes_pedigree_function": dpf,
        "physical_activity_hrs": physical_activity,
        "smoking": smoking,
        "family_history": family_history,
        "region": region,
        "healthcare_access": healthcare_access,
        "risk_score": risk_score.round(3),
        "probability": probability.round(3),
        "outcome": outcome,
        "diabetes_type": diabetes_type,
        "risk_level": risk_level,
    })

    # Save
    df.to_csv("data/diabetes_data.csv", index=False)

    # Print statistics
    print(f"\nDataset Generated: {n_samples} patient records")
    print(f"Diabetic cases: {outcome.sum()} ({outcome.mean()*100:.1f}%)")
    print(f"Non-diabetic: {n_samples - outcome.sum()} ({(1-outcome.mean())*100:.1f}%)")
    print(f"\nRegion distribution:")
    for r in regions:
        count = (region == r).sum()
        diabetic_in_region = outcome[region == r].sum()
        print(f"  {r}: {count} patients, {diabetic_in_region} diabetic ({diabetic_in_region/count*100:.1f}%)")
    print(f"\nDataset saved to data/diabetes_data.csv")
    print(f"\nFeature Summary:")
    print(df.describe().round(2).to_string())

    return df


if __name__ == "__main__":
    generate_diabetes_dataset()
